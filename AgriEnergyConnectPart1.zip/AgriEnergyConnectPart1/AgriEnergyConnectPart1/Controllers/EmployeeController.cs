﻿using Microsoft.AspNetCore.Mvc;

public class EmployeeController : Controller
{
    public string email = "";
    public string password = "";
    string employeeName = "Employee@example.com";
    string employeePassword = "123abc";
    // GET: /Employee/ManageFarmers
    public IActionResult Employee(string email, string password)
    {
        if(employeeName == email && employeePassword ==  password)
        {
            return View();
        }
        return Content("Invalid login");
    }

    /*
    public IActionResult Receivelogin(string email, string password)
    {
        //this.email = email;
        //this.password = password;
        Console.WriteLine($"employee name and password in database: ${employeeName}, ${employeePassword}");

        if (employeeName == email && employeePassword == password)
        {
            //return Content($"Received : {email} / {password}");
            return View();

        }
        // return Content("Invalid Login");
        return View();
    }
    */
}
