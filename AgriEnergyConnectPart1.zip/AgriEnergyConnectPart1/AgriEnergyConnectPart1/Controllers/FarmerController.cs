﻿using Microsoft.AspNetCore.Mvc;

public class FarmerController : Controller
{
    // GET: /Farmer/FarmerProducts
    public IActionResult FarmerProducts()
    {
        return View();
    }
}
